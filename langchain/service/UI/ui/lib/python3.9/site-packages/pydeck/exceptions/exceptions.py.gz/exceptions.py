class PydeckException(BaseException):
    pass


class BinaryTransportException(PydeckException):
    pass
