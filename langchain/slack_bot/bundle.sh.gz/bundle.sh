#!/usr/bin/env bash

./bundle_reader.sh 
./bundle_writer.sh